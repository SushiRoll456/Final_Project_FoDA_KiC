Data Description: This is a synthetic data set that has information pertaining to factors that may affect a person's preference towards the beach or the mountains. Variables include: Age, Gender, Income, Education Level, Travel Frequency, Preferred activities, Vacation Budget, Location, Proximity to Mountains, Proximity to Beach, Favorite Season, Pets, Environmental Concerns, and finally Preference. 

link to data set via Kaggle: 
https://www.kaggle.com/datasets/jahnavipaliwal/mountains-vs-beaches-preference 